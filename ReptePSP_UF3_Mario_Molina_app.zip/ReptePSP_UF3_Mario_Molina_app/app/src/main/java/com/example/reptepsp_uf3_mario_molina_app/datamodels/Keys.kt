package com.example.reptepsp_uf3_mario_molina_app.datamodels

class Keys
{
    object constKeys {

        const val LOGIN = "LOGIN"
        const val SALDO = "SALDO"
        const val TO_MAIN = "TO_MAIN"
        const val TO_MAIN_EXTRA = "TO_MAIN_EXTRA"
        const val MOD_USER = "MOD_USER"
        const val MOD_PASSWORD = "MOD_PASSWORD"
        const val TO_MOD_USER = "TO_MOD_USER"
        const val TO_JUGAR = "TO_JUGAR"
        const val TO_COMPRAR = "TO_COMPRAR"
    }
}